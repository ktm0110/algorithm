// priorityqueue.h
#pragma once

#include <queue>
#include <vector>

template<typename T, typename Priority>
struct PriorityQueue {
    typedef std::pair<Priority, T> PQElement;
    std::priority_queue<PQElement, std::vector<PQElement>, std::greater<PQElement>> elements;

    inline bool empty() const {
        return elements.empty();
    }

    inline void put(T item, Priority priority) {
        elements.emplace(priority, item);
    }

    inline T get() {
        T best_item = elements.top().second;
        elements.pop();
        return best_item;
    }
};